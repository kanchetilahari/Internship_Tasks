# Q1
from solutions import word_frequency
print("Q1 example:",word_frequency("python is easy and python is powerful"))
print("Q1 testcase:",word_frequency("apple banana apple"))

# Q2
from solutions import character_frequency
print("Q2 example:",character_frequency("banana"))
print("Q2 testcase:",character_frequency("hello"))
# Q3

from solutions import first_non_repeating
print("Q3 example:",first_non_repeating("swiss"))
print("Q3 testcase:",first_non_repeating("aabb"))



# Q5
from solutions import first_repeating_character
print("Q5 example:", first_repeating_character("programming"))
print("Q5 testcase:", first_repeating_character("hello"))


# Q6
from solutions import move_zeros
print("Q6 example:", move_zeros([0, 3, 0, 1, 2, 0, 4]))
print("Q6 testcase:", move_zeros([0, 1, 0, 2]))



# Q7
from solutions import second_highest
print("Q7 example:", second_highest([10, 20, 40, 30, 40, 20]))
print("Q7 testcase:", second_highest([5, 5, 3]))



# Q8
from solutions import remove_duplicates
print("Q8 example:", remove_duplicates([4, 2, 4, 5, 2, 7, 5]))
print("Q8 testcase:", remove_duplicates([1, 1, 2, 3, 2]))


# Q9
from solutions import missing_number
print("Q9 example:", missing_number([1, 2, 4, 5, 6], 6))
print("Q9 testcase:", missing_number([1, 2, 3, 5], 5))


# Q10
from solutions import two_sum
print("Q10 example:", two_sum([2, 7, 11, 15], 9))
print("Q10 testcase:", two_sum([1, 4, 6, 8], 20))


# Q11
from solutions import closest_to_zero
print("Q11 example:", closest_to_zero([-8, -3, 2, 5, -2]))
print("Q11 testcase:", closest_to_zero([-4, 3, 7]))


# Q12
from solutions import common_elements
print("Q12 example:", common_elements([1, 2, 3, 4, 5], [3, 4, 5, 6, 7]))
print("Q12testcase:", common_elements([4, 2, 4, 1], [4, 1, 5]))


# Q13
from solutions import rotate_right
print("Q13  example:", rotate_right([1, 2, 3, 4, 5], 2))
print("Q13 testcase:", rotate_right([10, 20, 30], 1))


# Q14
from solutions import max_consecutive_sum
print("Q14 example:", max_consecutive_sum([4, 7, 2, 9, 5]))
print("Q14 testcase:", max_consecutive_sum([1, 2, 8, 3]))


# Q15
from solutions import all_target_pairs
print("Q15 example:", all_target_pairs([2, 4, 3, 5, 7, 8, 1], 9))
print("Q15 testcase:", all_target_pairs([1, 2, 3, 4], 5))
