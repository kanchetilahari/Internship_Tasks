
# Q1: Find Frequency of Each Word
def word_frequency(sentence):
    frequency = {}
    for word in sentence.split():
        if word in frequency:
            frequency[word] += 1
        else:
            frequency[word] = 1
    return frequency


# Q2: Find Frequency of Each Character
def character_frequency(word):
    frequency = {}
    for char in word:
        if char in frequency:
            frequency[char] += 1
        else:
            frequency[char] = 1
    return frequency


# Q3: Find First Non-Repeating Character
def first_non_repeating(word):
    frequency = {}
    for char in word:
        if char in frequency:
            frequency[char] += 1
        else:
            frequency[char] = 1
    for char in word:
        if frequency[char] == 1:
            return char
    return None


# Q5: Find the First Repeating Character
def first_repeating_character(string):
    seen = set()
    for char in string:
        if char in seen:
            return char
        seen.add(char)
    return None


# Q6: Move All Zeros to the End
def move_zeros(nums):
    non_zeros = []
    for num in nums:
        if num != 0:
            non_zeros.append(num)
    zero_count = len(nums) - len(non_zeros)
    return non_zeros + [0] * zero_count



# Q7: Find the Second Highest Distinct Number
def second_highest(nums):
    unique_nums = sorted(set(nums), reverse=True)
    if len(unique_nums) < 2:
        return None
    return unique_nums[1]



# Q8: Remove Duplicates
def remove_duplicates(nums):
    result = []
    for num in nums:
        if num not in result:
            result.append(num)
    return result


# Q9: Find the Missing Number
def missing_number(nums, n):
    expected_sum = n * (n + 1) // 2
    actual_sum = sum(nums)
    return expected_sum - actual_sum



# Q10: Find the First Pair Matching a Target
def two_sum(nums, target):
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                return [nums[i], nums[j]]
    return []


# Q11: Find the Number Closest to Zero
def closest_to_zero(nums):
    return min(nums, key=lambda x: (abs(x), -x))


# Q12: Find Common Elements
def common_elements(list1, list2):
    result = []
    for num in list1:
        if num in list2 and num not in result:
            result.append(num)
    return result


# Q13: Rotate a List Right by K Positions
def rotate_right(nums, k):
    if not nums:
        return []
    k = k % len(nums)
    return nums[-k:] + nums[:-k] if k else nums[:]


# Q14: Maximum Sum of Two Consecutive Elements
def max_consecutive_sum(nums):
    max_sum = nums[0] + nums[1]
    for i in range(1, len(nums) - 1):
        current_sum = nums[i] + nums[i + 1]
        if current_sum > max_sum:
            max_sum = current_sum
    return max_sum



# Q15: Find All Unique Pairs Matching a Target
def all_target_pairs(nums, target):
    pairs = set()
    for i in range(len(nums)):
        for j in range(i + 1, len(nums)):
            if nums[i] + nums[j] == target:
                pair = tuple(sorted([nums[i], nums[j]]))
                pairs.add(pair)
    return [list(pair) for pair in sorted(pairs)]
